#!/usr/bin/env bash
#
# Ahmed Reaction Studio - offline native APK builder.
#
# Builds the Kotlin app into a signed, installable APK WITHOUT Gradle / AGP /
# AndroidX, using only:
#   kotlinc            (from npm "kotlin-compiler")
#   Temurin JDK 21     (from PyPI "jdk4py")
#   android-30.jar     (AOSP platform stub, committed on GitHub)
#   aapt2 (Linux)      (PyPI "aapt2")
#   d8.jar             (Android build-tools 28 lib)
#   apksigner.jar      (Android build-tools 26 lib)
#
# Set these env vars (or rely on the documented defaults):
#   TC_ROOT   root dir that holds: kotlinc/ java-runtime/ android.jar ...
#   JAVA_HOME path to a JDK/JRE 17+ runtime
#   KOTLINC   path to kotlinc executable
#   AAPT2     path to aapt2 (linux) binary
#   D8_JAR    path to d8.jar
#   APKSIGNER_JAR path to apksigner.jar
#   ANDROID_JAR   path to android.jar
#
# Output: artifacts/AhmedReactionStudio-1.0.0.apk  (signed, v1+v2)

set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="AhmedReactionStudio"
VER="1.0.0"
PKG="com.rehman.ahmedreactionstudio"

TC_ROOT="${TC_ROOT:-/tmp/ahmed-tc}"
JAVA_HOME="${JAVA_HOME:-$TC_ROOT/java-runtime}"
KOTLINC="${KOTLINC:-$TC_ROOT/kotlinc/bin/kotlinc}"
AAPT2="${AAPT2:-$TC_ROOT/aapt2}"
D8_JAR="${D8_JAR:-$TC_ROOT/d8.jar}"
APKSIGNER_JAR="${APKSIGNER_JAR:-$TC_ROOT/apksigner.jar}"
ANDROID_JAR="${ANDROID_JAR:-$TC_ROOT/android.jar}"
ANDROID_JAR_D8="${ANDROID_JAR_D8:-$TC_ROOT/android-d8.jar}"
STD_LIB="${STD_LIB:-$TC_ROOT/kotlin-stdlib.jar}"

KS="${KS:-$TC_ROOT/ahmed.keystore}"
KS_PASS="${KS_PASS:-ahmed123}"
KS_ALIAS="${KS_ALIAS:-app}"

export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"

# Timestamped, memory-aware phase logging: if a CI runner ever kills a step
# (e.g. exit 137), the uploaded build log pinpoints exactly which phase died
# and how much RAM was left at the time.
say() {
    local avail
    avail="$(awk '/MemAvailable/ { printf "%d MB", $2/1024 }' /proc/meminfo 2>/dev/null || echo '?')"
    echo "[$(date -u +%H:%M:%S)] $* (mem available: $avail)"
}

BUILD="build_out"
rm -rf "$BUILD"
mkdir -p "$BUILD/dex" "$BUILD/gen" "artifacts"

say "== 1/7 aapt2 resources + generated R class =="
"$AAPT2" compile --dir res -o "$BUILD/res.zip"
"$AAPT2" link -I "$ANDROID_JAR" \
    --manifest app/AndroidManifest.xml \
    --min-sdk-version 26 --target-sdk-version 30 \
    --java "$BUILD/gen" \
    -o "$BUILD/base.apk" "$BUILD/res.zip"

say "== 2/7 convert R.java -> R.kt (the jdk4py runtime has no javac) =="
python3 - "$BUILD" <<'PY'
import sys, os, re, glob
b = sys.argv[1]
cands = glob.glob(os.path.join(b, 'gen', '**', 'R.java'), recursive=True)
if not cands:
    raise SystemExit('aapt2 did not generate R.java')
text = open(cands[0]).read()
pkg = re.search(r'package\s+([\w.]+);', text).group(1)
lines = ['@file:Suppress("unused", "ConstPropertyName")', f'package {pkg}', '', 'object R {']
for cm in re.finditer(r'public static final class (\w+) \{(.*?)\n  \}', text, re.S):
    cls, body = cm.group(1), cm.group(2)
    entries = re.findall(r'public static final int (\w+)\s*=\s*(0x[0-9a-fA-F]+);', body)
    if not entries:
        continue
    lines.append(f'    object {cls} {{')
    for name, value in entries:
        lines.append(f'        const val {name}: Int = {value}')
    lines.append('    }')
lines.append('}')
out = os.path.join(b, 'R.kt')
open(out, 'w').write('\n'.join(lines) + '\n')
print(f'R.kt written for package {pkg}')
PY

say "== 3/7 compile Kotlin =="
find app/src -name '*.kt' > "$BUILD/sources.txt"
echo "$BUILD/R.kt" >> "$BUILD/sources.txt"
# The bundled kotlinc launcher starts its JVM with only -Xmx256M unless
# JAVA_OPTS is set. On memory-pressured CI runners that intermittently gets
# OOM-killed mid-compile (exit 137) — the app compiles fine, but the runner
# reaps the process and NO apk is produced. Give the compiler a real heap and
# disable the daemon so the build is deterministic, then retry once with an
# even larger heap if the first attempt is killed.
export JAVA_OPTS="${KOTLINC_JAVA_OPTS:--Xmx2g -Xms256m -XX:+UseParallelGC -XX:MaxMetaspaceSize=512m}"
kotlin_compile() {
    local heap="$1"
    JAVA_OPTS="-Xmx${heap} -Xms256m -XX:+UseParallelGC -XX:MaxMetaspaceSize=512m" \
        "$KOTLINC" -jvm-target 1.8 \
        -classpath "$ANDROID_JAR" -d "$BUILD/classes" @"$BUILD/sources.txt"
}
if ! kotlin_compile 2g; then
    say "!! kotlinc failed or was killed — retrying once with a larger heap (4g)"
    rm -rf "$BUILD/classes"
    kotlin_compile 4g
fi
# Fail loudly if the compile produced nothing (killed process can exit 0-ish
# through a pipe on some shells); the whole point is to never ship a stale apk.
if [ ! -d "$BUILD/classes" ] || [ -z "$(find "$BUILD/classes" -name '*.class' -print -quit)" ]; then
    echo "FATAL: Kotlin compilation produced no .class files — aborting so a stale APK is never shipped." >&2
    exit 1
fi

say "== 4/7 dex with d8 =="
python3 - "$BUILD" <<'PY'
import sys, zipfile, os
b = sys.argv[1]
if not os.path.isdir(os.path.join(b, 'classes')):
    raise SystemExit('missing classes dir')
with zipfile.ZipFile(os.path.join(b, 'classes.jar'), 'w', zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(os.path.join(b, 'classes')):
        for f in files:
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, os.path.join(b, 'classes')))
PY
# d8 only needs the library jar for API-level resolution; the newer API
# stub is compiled with Java 17 bytecode which old d8 can't parse, so feed
# it the Java-8 API-30 stub while compiling sources against the newer one.
java -cp "$D8_JAR" com.android.tools.r8.D8 --release --lib "$ANDROID_JAR_D8" --min-api 26 \
    --output "$BUILD/dex" "$BUILD/classes.jar" "$STD_LIB"

say "== 5/7 assemble apk =="
python3 - "$BUILD" "$APP_NAME" "$VER" "$PKG" <<'PY'
import sys, zipfile, os
b, name, ver, pkg = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
with zipfile.ZipFile(os.path.join(b, 'base.apk')) as src:
    entries = {i.filename: src.read(i.filename) for i in src.infolist()}
with zipfile.ZipFile(os.path.join(b, 'unsigned.apk'), 'w', zipfile.ZIP_DEFLATED) as z:
    for fn, data in entries.items():
        z.writestr(fn, data)
    z.write(os.path.join(b, 'dex', 'classes.dex'), 'classes.dex')
print('unsigned.apk entries:', list(zipfile.ZipFile(os.path.join(b, 'unsigned.apk')).namelist()))
PY

say "== 6/7 sign (v1+v2) =="
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias "$KS_ALIAS" -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=Ahmed Reaction Studio,O=Ahmed Studio,C=US" >/dev/null 2>&1
fi
java -jar "$APKSIGNER_JAR" sign --ks "$KS" --ks-key-alias "$KS_ALIAS" \
    --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
    --v1-signing-enabled true --v2-signing-enabled true \
    --out "artifacts/$APP_NAME-$VER.apk" "$BUILD/unsigned.apk"

say "== 7/7 verify =="
java -jar "$APKSIGNER_JAR" verify --print-certs "artifacts/$APP_NAME-$VER.apk" | head -6
ls -la "artifacts/$APP_NAME-$VER.apk"
echo "BUILD OK"
